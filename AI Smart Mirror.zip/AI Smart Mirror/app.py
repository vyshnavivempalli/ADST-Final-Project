from flask import Flask, render_template, request, redirect, url_for, session, send_from_directory
from PIL import Image
from werkzeug.utils import secure_filename
import os
import time

app = Flask(__name__)
app.secret_key = "smart_mirror_final_project_2026"

UPLOAD_FOLDER = "uploads"
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

os.makedirs(UPLOAD_FOLDER, exist_ok=True)


# =========================================================
# DEMO WEATHER
# =========================================================

def get_weather():
    return 26, "Cloudy", 70


# =========================================================
# IMAGE COLOUR ANALYSIS
# =========================================================

def get_dominant_color(image_path):

    image = Image.open(image_path).convert("RGB")
    image.thumbnail((150, 150))

    pixels = list(image.getdata())

    useful_pixels = []

    for r, g, b in pixels:
        brightness = (r + g + b) / 3

        if 20 < brightness < 245:
            useful_pixels.append((r, g, b))

    if not useful_pixels:
        useful_pixels = pixels

    r = sum(p[0] for p in useful_pixels) // len(useful_pixels)
    g = sum(p[1] for p in useful_pixels) // len(useful_pixels)
    b = sum(p[2] for p in useful_pixels) // len(useful_pixels)

    return r, g, b


def color_name(rgb):

    r, g, b = rgb

    if r > 200 and g > 200 and b > 200:
        return "White"

    if r < 55 and g < 55 and b < 55:
        return "Black"

    if abs(r - g) < 18 and abs(g - b) < 18:
        return "Grey"

    if r > g * 1.35 and r > b * 1.35:
        return "Red"

    if b > r * 1.25 and b > g * 1.10:
        return "Blue"

    if g > r * 1.20 and g > b * 1.15:
        return "Green"

    if r > 150 and g > 120 and b < 100:
        return "Yellow"

    if r > 100 and g > 65 and b < 70:
        return "Brown"

    if r > 120 and b > 100 and g < 100:
        return "Purple"

    if r > 130 and g > 70 and b < 80:
        return "Orange"

    return "Other"


# =========================================================
# PATTERN ANALYSIS
# =========================================================

def detect_pattern(image_path):

    image = Image.open(image_path).convert("RGB")
    image = image.resize((80, 80))

    pixels = list(image.getdata())

    avg_r = sum(p[0] for p in pixels) / len(pixels)
    avg_g = sum(p[1] for p in pixels) / len(pixels)
    avg_b = sum(p[2] for p in pixels) / len(pixels)

    variation = 0

    for r, g, b in pixels:
        variation += abs(r - avg_r)
        variation += abs(g - avg_g)
        variation += abs(b - avg_b)

    variation /= len(pixels)

    if variation < 35:
        return "Plain"

    elif variation < 65:
        return "Light Pattern"

    else:
        return "Patterned"


# =========================================================
# COLOUR MATCHING
# =========================================================

def matching_colors(colour):

    matches = {
        "Blue": ["Black", "White", "Grey", "Beige"],
        "Black": ["White", "Grey", "Blue", "Beige"],
        "White": ["Blue", "Black", "Grey", "Brown"],
        "Red": ["Black", "White", "Dark Blue", "Grey"],
        "Green": ["Black", "White", "Beige", "Brown"],
        "Yellow": ["Black", "White", "Blue", "Grey"],
        "Brown": ["White", "Beige", "Black", "Blue"],
        "Grey": ["Black", "White", "Blue", "Maroon"],
        "Purple": ["White", "Black", "Grey", "Beige"],
        "Orange": ["White", "Black", "Blue", "Brown"],
        "Other": ["Black", "White", "Grey", "Beige"]
    }

    return matches.get(
        colour,
        ["Black", "White", "Grey", "Beige"]
    )


# =========================================================
# OUTFIT GENERATION
# =========================================================

def generate_outfits(
    clothing_type,
    colour,
    style,
    temperature,
    condition
):

    matches = matching_colors(colour)

    bottom = "Black Jeans"
    shoes = "White Sneakers"

    if clothing_type == "Shirt":
        top = f"{colour} Shirt"

    elif clothing_type == "T-Shirt":
        top = f"{colour} T-Shirt"

    elif clothing_type == "Jeans":
        top = f"{colour} Jeans"
        bottom = "White T-Shirt"

    elif clothing_type == "Trousers":
        top = f"{colour} Trousers"
        bottom = "White Shirt"

    elif clothing_type == "Dress":
        top = f"{colour} Dress"
        bottom = "Simple Accessories"

    elif clothing_type == "Jacket":
        top = f"{colour} Jacket"
        bottom = "Black Jeans"

    elif clothing_type == "Skirt":
        top = f"{colour} Skirt"
        bottom = "White Top"

    else:
        top = f"{colour} Clothing"

    if temperature >= 30:

        weather_note = (
            "Choose lightweight and breathable clothing."
        )

        shoes = "Light Sneakers"

    elif temperature >= 25:

        weather_note = (
            "Comfortable weather for lightweight clothing."
        )

    elif temperature >= 20:

        weather_note = (
            "Moderate weather. A light layer can be useful."
        )

    else:

        weather_note = (
            "Cool weather. Consider adding a jacket."
        )

    if "Rain" in condition:

        weather_note = (
            "Rainy weather. Choose comfortable clothing "
            "and carry rain protection."
        )

    if style == "Formal":

        style_bottom = "Formal Trousers"
        style_shoes = "Formal Shoes"

    elif style == "Party":

        style_bottom = "Stylish Dark Trousers"
        style_shoes = "Fashion Sneakers"

    else:

        style_bottom = bottom
        style_shoes = shoes

    outfits = [

        {
            "title": "Best Match",
            "score": 92,
            "icon": "🥇",
            "top": top,
            "bottom": style_bottom,
            "shoes": style_shoes,
            "match": matches[0],
            "description": weather_note
        },

        {
            "title": "Smart Casual",
            "score": 86,
            "icon": "🥈",
            "top": top,
            "bottom": f"{matches[1]} Trousers",
            "shoes": "White Sneakers",
            "match": matches[1],
            "description": (
                "A balanced combination for a comfortable "
                "everyday look."
            )
        },

        {
            "title": "Alternative Look",
            "score": 81,
            "icon": "🥉",
            "top": top,
            "bottom": f"{matches[2]} Bottoms",
            "shoes": "Casual Sneakers",
            "match": matches[2],
            "description": (
                "An alternative combination when you want "
                "a different appearance."
            )
        }

    ]

    return outfits


# =========================================================
# COMPATIBILITY SCORE
# =========================================================

def calculate_scores(colour, style, temperature):

    if colour in [
        "Blue",
        "Black",
        "White",
        "Grey"
    ]:
        colour_score = 95
    else:
        colour_score = 88

    weather_score = 92

    if temperature >= 30:
        weather_score = 88

    elif temperature < 20:
        weather_score = 86

    if style in [
        "Casual",
        "Formal",
        "Party"
    ]:
        style_score = 94
    else:
        style_score = 85

    overall = int(
        (
            colour_score
            + weather_score
            + style_score
        ) / 3
    )

    return (
        colour_score,
        weather_score,
        style_score,
        overall
    )


# =========================================================
# SIGN UP
# =========================================================

@app.route("/")
def signin():
    return render_template("signin.html")


@app.route("/signin", methods=["POST"])
def create_account():

    name = request.form.get(
        "name",
        ""
    ).strip()

    email = request.form.get(
        "email",
        ""
    ).strip()

    password = request.form.get(
        "password",
        ""
    ).strip()

    if not name or not email or not password:

        return render_template(
            "signin.html",
            error="Please fill in all fields."
        )

    session["name"] = name
    session["email"] = email
    session["password"] = password

    return redirect(
        url_for("login")
    )


# =========================================================
# LOGIN
# =========================================================

@app.route("/login")
def login():

    return render_template(
        "login.html"
    )


@app.route("/login", methods=["POST"])
def login_user():

    email = request.form.get(
        "email",
        ""
    ).strip()

    password = request.form.get(
        "password",
        ""
    ).strip()

    if (
        email == session.get("email")
        and password == session.get("password")
    ):

        session["logged_in"] = True

        return redirect(
            url_for("dashboard")
        )

    return render_template(
        "login.html",
        error="Incorrect email or password."
    )


# =========================================================
# DASHBOARD
# =========================================================

@app.route("/dashboard")
def dashboard():

    if not session.get("logged_in"):
        return redirect(
            url_for("login")
        )

    temperature, condition, humidity = get_weather()

    return render_template(
        "dashboard.html",
        name=session.get(
            "name",
            "User"
        ),
        email=session.get(
            "email",
            ""
        ),
        temperature=temperature,
        condition=condition,
        humidity=humidity
    )


# =========================================================
# IMAGE UPLOAD + AI ANALYSIS
# =========================================================

@app.route("/upload", methods=["POST"])
def upload():

    if not session.get("logged_in"):
        return redirect(
            url_for("login")
        )

    file = request.files.get(
        "clothing"
    )

    clothing_type = request.form.get(
        "clothing_type",
        "T-Shirt"
    )

    style = request.form.get(
        "style",
        "Casual"
    )

    if not file or file.filename == "":
        return redirect(
            url_for("dashboard")
        )

    original_name = secure_filename(
        file.filename
    )

    filename = (
        str(int(time.time()))
        + "_"
        + original_name
    )

    file_path = os.path.join(
        app.config["UPLOAD_FOLDER"],
        filename
    )

    file.save(file_path)

    rgb = get_dominant_color(
        file_path
    )

    detected_colour = color_name(
        rgb
    )

    pattern = detect_pattern(
        file_path
    )

    temperature, condition, humidity = get_weather()

    (
        colour_score,
        weather_score,
        style_score,
        overall_score
    ) = calculate_scores(
        detected_colour,
        style,
        temperature
    )

    outfits = generate_outfits(
        clothing_type,
        detected_colour,
        style,
        temperature,
        condition
    )

    return render_template(
        "dashboard.html",

        name=session.get(
            "name",
            "User"
        ),

        email=session.get(
            "email",
            ""
        ),

        temperature=temperature,
        condition=condition,
        humidity=humidity,

        filename=filename,

        detected_colour=detected_colour,
        pattern=pattern,
        clothing_type=clothing_type,
        style=style,

        colour_score=colour_score,
        weather_score=weather_score,
        style_score=style_score,
        overall_score=overall_score,

        matches=matching_colors(
            detected_colour
        ),

        outfits=outfits,

        analyzed=True
    )


# =========================================================
# SHOW UPLOADED IMAGE
# =========================================================

@app.route("/uploads/<filename>")
def uploaded_file(filename):

    return send_from_directory(
        app.config["UPLOAD_FOLDER"],
        filename
    )


# =========================================================
# LOGOUT
# =========================================================

@app.route("/logout")
def logout():

    session.clear()

    return redirect(
        url_for("login")
    )


# =========================================================
# RUN APPLICATION
# =========================================================

if __name__ == "__main__":
    app.run(debug=True)